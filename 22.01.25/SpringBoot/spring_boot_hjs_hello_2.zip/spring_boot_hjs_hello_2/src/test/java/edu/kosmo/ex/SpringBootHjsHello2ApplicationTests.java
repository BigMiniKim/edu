package edu.kosmo.ex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootHjsHello2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
