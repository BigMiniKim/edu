package edu.kosmo.ex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootHjsHello2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootHjsHello2Application.class, args);
	}

}
