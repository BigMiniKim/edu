package com.javalec.ex.student;


public class StudentInfo {
	
	private Student student;
		
	public StudentInfo() {}
	
	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}
}
