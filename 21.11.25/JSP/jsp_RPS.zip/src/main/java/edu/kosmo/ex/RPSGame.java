package edu.kosmo.ex;


public class RPSGame {

	private int rps;

	public RPSGame(String rps) {

		if (rps.equals("scissors"))
			this.rps = 1;
		else if (rps.equals("rock"))
			this.rps = 2;
		else
			this.rps = 3;
	}


	public RPSGame() {
		this.rps = (int) (Math.random() * 3 + 1); 
	}

	public String getResult(RPSGame rps) {
		String res;

		if (this.rps == RPSGame.rps) {

			res= "비겼습니다";
		}
		
		if (this.rps == 1 && player.rps == 2) {
			res = "제가 졌습니다";
		} else if (this.rps == 1 && player.rps == 3) {
			res = "제가 이겼습니다";
		} else if (this.rps == 2 && player.rps == 1) {
			res = "제가 이겼습니다";
		} else if (this.rps == 2 && player.rps == 3) {
			res = "제가 졌습니다";
		} else if (this.rps == 3 && player.rps == 1) {
			res = "제가 졌습니다";
		} else if (this.rps == 3 && player.rps == 2) {
			res = "제가 이겼습니다";
		}
		

	}
		
}
