package edu.kosmo.ex;

import java.util.ArrayList;

public class Lotto_main {
	public Lotto_main(){}
	public ArrayList getLotto(){
		ArrayList al = new ArrayList();
		//45개의 정수값 저장을 위한 배열 생성
		int ball[] = new int[45];
		
		//배열의 각 요소에 1~45의 값을 저장하기
		for(int i = 0; i < ball.length; i++ ){
			ball[i] = i + 1;
		}
	    int temp = 0;//두 값을 바꾸는데 사용하는 임시변수
	    int j = 0;//임의의 값을 얻어서 저장할 변수
	    //배열에 저장된 값이 잘 섞일 수 있게충분히 큰 반복횟수를 지정함 (배열 크기의 두배정도)
	    //배열의 첫번째 요소와 임시 변수에 저장된 값을 서로 바꾼다
	    for(int i = 0; i < 100 ; i++){
	    	j= (int)(Math.random() * 45); //ball[0]~ball[44] 총45개이므로 44까지 랜덤으로 출력되면 잘 섞임
	    	temp = ball[0];
	    	ball[0] = ball[j];
	    	ball[j] = temp;
	    }
		for(int k =0; k<6 ; k++){
	      al.add(ball[k]);
		}
		return al;
	}
}
		