package edu.kosmo.ex.service;

public interface SocialService {
	String getAuthorizationUrl();
}
